"""maintain history for compatibility with earlier migrations

Revision ID: 13eb55f81627
Revises: 1507a7289a2f
Create Date: 2015-08-23 05:12:49.732174

"""

# revision identifiers, used by Alembic.
revision = '13eb55f81627'
down_revision = '1507a7289a2f'
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    pass