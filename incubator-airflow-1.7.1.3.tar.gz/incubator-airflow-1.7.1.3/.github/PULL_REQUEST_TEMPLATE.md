Dear Airflow Maintainers,

Please accept the following PR that
* Addresses the following issues (links to issues addressed by this PR) :

Reminder to contributors:
* You must add an Apache License header to all new files
* Please squash your commits when possible and follow the [7 rules of good Git commits](http://chris.beams.io/posts/git-commit/#seven-rules)
