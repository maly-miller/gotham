#!/bin/bash
source $AIRFLOW_HOME/env/bin/activate
