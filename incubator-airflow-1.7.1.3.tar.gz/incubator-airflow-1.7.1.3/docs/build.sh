#!/usr/bin/env bash
rm -r _build
make html
