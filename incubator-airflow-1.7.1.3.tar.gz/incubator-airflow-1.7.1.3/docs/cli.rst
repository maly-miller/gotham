Command Line Interface
======================

Airflow has a very rich command line interface that allows for
many types of operation on a DAG, starting services, and supporting
development and testing.

.. argparse::
   :module: airflow.bin.cli
   :func: get_parser
   :prog: airflow
